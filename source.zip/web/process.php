<?php

$str = $_GET["Name"];
$str = $_GET["Email"];
$str = $_GET["Message"];

$servername = "localhost";
$username = "bofa";
$password = "deez";
$dbname = "mydb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO text (Name, Email, Message)
VALUES ('$str', 'Doe', 'john@example.com')";

if ($conn->query($sql) === TRUE) {
    echo "Thank you for your submission!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();



?> 